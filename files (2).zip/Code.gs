/**
 * FinTrack — Personal Finance PWA
 * Backend: Google Apps Script + Google Sheets sebagai database.
 * Deploy: Deploy > New deployment > Web app > Execute as: Me > Who has access: Only myself (atau sesuai kebutuhan).
 */

var SHEET_TX = 'Transactions';
var SHEET_GOALS = 'Goals';
var SHEET_SETTINGS = 'Settings';

var TX_HEADERS = ['id', 'type', 'amount', 'category', 'note', 'date', 'isRecurring', 'recurringDay', 'createdAt', 'allocations', 'sourcePocketId'];
var GOAL_HEADERS = ['id', 'name', 'emoji', 'targetAmount', 'savedAmount', 'durationYears', 'reminderDay', 'reminderEnabled', 'createdAt', 'color', 'allocations', 'allowExpense'];

var MONTHS_ID = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
var GOAL_COLORS = ['#FCD535', '#3B82F6', '#8B5CF6', '#EC4899', '#2DBDB6'];

/* ============================== ENTRY POINT (JSON API) ============================== */
/**
 * Backend ini sekarang berfungsi sebagai API JSON murni.
 * Frontend (index.html) di-hosting terpisah secara statis (GitHub Pages/Firebase Hosting)
 * dan memanggil Web App URL ini via fetch().
 */

var API_ACTIONS = {
  getInitialData: getInitialData,
  listTransactions: listTransactions,
  listGoals: listGoals,
  getSettings: getSettings,
  updateSettings: updateSettings,
  addTransaction: addTransaction,
  updateTransaction: updateTransaction,
  deleteTransaction: deleteTransaction,
  addGoal: addGoal,
  updateGoal: updateGoal,
  deleteGoal: deleteGoal,
  depositToGoal: depositToGoal,
  addAllocationItem: addAllocationItem,
  updateAllocationItem: updateAllocationItem,
  deleteAllocationItem: deleteAllocationItem,
  getReport: getReport,
  getAnalytics: getAnalytics,
  getSalaryAllocationRules: getSalaryAllocationRules,
  updateSalaryAllocationRules: updateSalaryAllocationRules,
  exportReportPdf: exportReportPdf,
  exportReportDocx: exportReportDocx,
  exportReportExcel: exportReportExcel,
  exportAllDataExcel: exportAllDataExcel,
  resetAllData: resetAllData
};

function doGet(e) {
  if (e && e.parameter && e.parameter.action) return handleRequest_(e);
  return jsonOut_({ success: true, message: 'FinTrack API aktif. Gunakan action= untuk memanggil fungsi, atau POST untuk operasi tulis.' });
}

function doPost(e) {
  return handleRequest_(e);
}

function handleRequest_(e) {
  try {
    ensureSheets_();
    var action, args;
    if (e.postData && e.postData.contents) {
      var body = JSON.parse(e.postData.contents);
      action = body.action;
      args = body.args || [];
    } else {
      action = e.parameter.action;
      args = e.parameter.args ? JSON.parse(e.parameter.args) : [];
    }
    var fn = API_ACTIONS[action];
    if (!fn) return jsonOut_({ success: false, error: 'Unknown action: ' + action });
    var result = fn.apply(null, args);
    return jsonOut_({ success: true, data: result });
  } catch (err) {
    return jsonOut_({ success: false, error: String(err && err.message ? err.message : err) });
  }
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/* ============================== SHEET HELPERS ============================== */

function ensureSheets_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  createSheetIfMissing_(ss, SHEET_TX, TX_HEADERS);
  createSheetIfMissing_(ss, SHEET_GOALS, GOAL_HEADERS);
  createSheetIfMissing_(ss, SHEET_SETTINGS, ['key', 'value']);
  ensureDefaultSettings_();
}

function createSheetIfMissing_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(headers);
    sh.setFrozenRows(1);
  }
  return sh;
}

function getSheet_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(name) || createSheetIfMissing_(ss, name, name === SHEET_TX ? TX_HEADERS : (name === SHEET_GOALS ? GOAL_HEADERS : ['key', 'value']));
}

function sheetToObjects_(sheetName, headers) {
  var sh = getSheet_(sheetName);
  var last = sh.getLastRow();
  if (last < 2) return [];
  var values = sh.getRange(2, 1, last - 1, headers.length).getValues();
  var out = [];
  for (var i = 0; i < values.length; i++) {
    var row = values[i];
    if (!row[0]) continue;
    var obj = {};
    for (var j = 0; j < headers.length; j++) {
      obj[headers[j]] = row[j];
    }
    out.push(rowPostProcess_(obj));
  }
  return out;
}

function rowPostProcess_(obj) {
  if ('allocations' in obj) {
    try { obj.allocations = obj.allocations ? JSON.parse(obj.allocations) : []; } catch (e) { obj.allocations = []; }
  }
  if ('amount' in obj) obj.amount = Number(obj.amount) || 0;
  if ('targetAmount' in obj) obj.targetAmount = Number(obj.targetAmount) || 0;
  if ('savedAmount' in obj) obj.savedAmount = Number(obj.savedAmount) || 0;
  if ('durationYears' in obj) obj.durationYears = Number(obj.durationYears) || 1;
  if ('reminderDay' in obj) obj.reminderDay = Number(obj.reminderDay) || 1;
  if ('isRecurring' in obj) obj.isRecurring = obj.isRecurring === true || obj.isRecurring === 'TRUE' || obj.isRecurring === 'true';
  if ('reminderEnabled' in obj) obj.reminderEnabled = obj.reminderEnabled === true || obj.reminderEnabled === 'TRUE' || obj.reminderEnabled === 'true';
  if ('allowExpense' in obj) obj.allowExpense = obj.allowExpense === true || obj.allowExpense === 'TRUE' || obj.allowExpense === 'true';
  if ('recurringDay' in obj && obj.recurringDay !== '') obj.recurringDay = Number(obj.recurringDay);
  if ('date' in obj && obj.date instanceof Date) {
    obj.date = Utilities.formatDate(obj.date, Session.getScriptTimeZone() || 'GMT+7', 'yyyy-MM-dd');
  }
  return obj;
}

function findRowIndexById_(sheetName, headers, id) {
  var sh = getSheet_(sheetName);
  var last = sh.getLastRow();
  if (last < 2) return -1;
  var ids = sh.getRange(2, 1, last - 1, 1).getValues();
  for (var i = 0; i < ids.length; i++) {
    if (ids[i][0] === id) return i + 2;
  }
  return -1;
}

function objectToRow_(obj, headers) {
  return headers.map(function (h) {
    var v = obj[h];
    if (h === 'allocations') return JSON.stringify(v || []);
    if (v === undefined || v === null) return '';
    return v;
  });
}

function appendObject_(sheetName, headers, obj) {
  var sh = getSheet_(sheetName);
  sh.appendRow(objectToRow_(obj, headers));
}

function updateObjectById_(sheetName, headers, id, obj) {
  var rowIdx = findRowIndexById_(sheetName, headers, id);
  if (rowIdx === -1) return false;
  var sh = getSheet_(sheetName);
  sh.getRange(rowIdx, 1, 1, headers.length).setValues([objectToRow_(obj, headers)]);
  return true;
}

function deleteObjectById_(sheetName, headers, id) {
  var rowIdx = findRowIndexById_(sheetName, headers, id);
  if (rowIdx === -1) return false;
  getSheet_(sheetName).deleteRow(rowIdx);
  return true;
}

/* ============================== SETTINGS ============================== */

function ensureDefaultSettings_() {
  var sh = getSheet_(SHEET_SETTINGS);
  var last = sh.getLastRow();
  var existing = {};
  if (last >= 2) {
    var values = sh.getRange(2, 1, last - 1, 2).getValues();
    values.forEach(function (r) { existing[r[0]] = r[1]; });
  }
  var defaults = { userName: 'Kamu', currency: 'IDR', darkMode: true, startDate: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'GMT+7', 'yyyy-MM-dd'), onboarded: false, salaryAllocationRules: JSON.stringify([]) };
  var toAdd = [];
  Object.keys(defaults).forEach(function (k) {
    if (!(k in existing)) toAdd.push([k, defaults[k]]);
  });
  if (toAdd.length) sh.getRange(sh.getLastRow() + 1, 1, toAdd.length, 2).setValues(toAdd);
}

function getSettings() {
  ensureSheets_();
  var sh = getSheet_(SHEET_SETTINGS);
  var last = sh.getLastRow();
  var out = {};
  if (last >= 2) {
    var values = sh.getRange(2, 1, last - 1, 2).getValues();
    values.forEach(function (r) { out[r[0]] = r[1]; });
  }
  return out;
}

function updateSettings(updates) {
  ensureSheets_();
  var sh = getSheet_(SHEET_SETTINGS);
  var last = sh.getLastRow();
  var values = last >= 2 ? sh.getRange(2, 1, last - 1, 2).getValues() : [];
  var keys = values.map(function (r) { return r[0]; });
  Object.keys(updates).forEach(function (k) {
    var idx = keys.indexOf(k);
    if (idx > -1) {
      sh.getRange(idx + 2, 2).setValue(updates[k]);
    } else {
      sh.appendRow([k, updates[k]]);
    }
  });
  return getSettings();
}

/* ============================== TRANSACTIONS ============================== */

function listTransactions() {
  ensureSheets_();
  return sheetToObjects_(SHEET_TX, TX_HEADERS).sort(function (a, b) { return b.createdAt - a.createdAt; });
}

function addTransaction(tx) {
  ensureSheets_();
  tx.id = Utilities.getUuid();
  tx.createdAt = Date.now();
  tx.isRecurring = !!tx.isRecurring;
  tx.recurringDay = tx.recurringDay || '';
  tx.allocations = [];
  tx.sourcePocketId = tx.sourcePocketId || '';

  var allocationBreakdown = [];

  if (tx.type === 'income') {
    if (tx.category === 'salary') {
      allocationBreakdown = applySalaryAllocation_(tx);
    } else if (tx.allocateToPocketId) {
      var goals = listGoals();
      var target = goals.filter(function (g) { return g.id === tx.allocateToPocketId; })[0];
      if (target) {
        target.savedAmount = Number(target.savedAmount || 0) + Number(tx.amount);
        updateObjectById_(SHEET_GOALS, GOAL_HEADERS, target.id, target);
        var entry = { goalId: target.id, goalName: target.name, amount: Number(tx.amount) };
        tx.allocations.push(entry);
        allocationBreakdown.push(entry);
      }
    }
  } else if (tx.type === 'expense' && tx.sourcePocketId) {
    var goals2 = listGoals();
    var pocket = goals2.filter(function (g) { return g.id === tx.sourcePocketId; })[0];
    if (pocket) {
      pocket.savedAmount = Number(pocket.savedAmount || 0) - Number(tx.amount);
      updateObjectById_(SHEET_GOALS, GOAL_HEADERS, pocket.id, pocket);
    }
  }

  appendObject_(SHEET_TX, TX_HEADERS, tx);
  return { transaction: tx, allocationBreakdown: allocationBreakdown };
}

/**
 * Membagi otomatis pemasukan berkategori "salary" (gajian) sesuai aturan
 * yang diatur user di Settings > Aturan Alokasi Gajian.
 * Urutan proses: nominal tetap dulu -> persentase -> sisa (remainder) terakhir.
 */
function applySalaryAllocation_(tx) {
  var rules = getSalaryAllocationRules();
  if (!rules.length) return [];
  var goals = listGoals();
  var goalsById = {};
  goals.forEach(function (g) { goalsById[g.id] = g; });

  var fixedRules = rules.filter(function (r) { return r.mode === 'fixed'; });
  var pctRules = rules.filter(function (r) { return r.mode === 'percentage'; });
  var remainderRules = rules.filter(function (r) { return r.mode === 'remainder'; });

  var remaining = Number(tx.amount);
  var breakdown = [];

  function applyToPocket(pocketId, amount) {
    amount = Math.round(amount);
    if (amount <= 0 || !goalsById[pocketId]) return;
    var g = goalsById[pocketId];
    g.savedAmount = Number(g.savedAmount || 0) + amount;
    updateObjectById_(SHEET_GOALS, GOAL_HEADERS, g.id, g);
    var entry = { goalId: g.id, goalName: g.name, amount: amount };
    tx.allocations.push(entry);
    breakdown.push(entry);
  }

  fixedRules.forEach(function (r) {
    var amt = Math.min(remaining, Number(r.amount || 0));
    applyToPocket(r.pocketId, amt);
    remaining -= amt;
  });
  pctRules.forEach(function (r) {
    var amt = Math.min(remaining, Math.round(Number(tx.amount) * Number(r.percentage || 0) / 100));
    applyToPocket(r.pocketId, amt);
    remaining -= amt;
  });
  if (remainderRules.length && remaining > 0) {
    var share = Math.floor(remaining / remainderRules.length);
    remainderRules.forEach(function (r, idx) {
      var amt = (idx === remainderRules.length - 1) ? (remaining - share * (remainderRules.length - 1)) : share;
      applyToPocket(r.pocketId, amt);
    });
  }
  return breakdown;
}

function getSalaryAllocationRules() {
  var s = getSettings();
  try { return s.salaryAllocationRules ? JSON.parse(s.salaryAllocationRules) : []; } catch (e) { return []; }
}

function updateSalaryAllocationRules(rules) {
  updateSettings({ salaryAllocationRules: JSON.stringify(rules || []) });
  return rules;
}

function updateTransaction(id, updates) {
  ensureSheets_();
  var all = sheetToObjects_(SHEET_TX, TX_HEADERS);
  var tx = all.filter(function (t) { return t.id === id; })[0];
  if (!tx) return null;
  Object.keys(updates).forEach(function (k) { tx[k] = updates[k]; });
  updateObjectById_(SHEET_TX, TX_HEADERS, id, tx);
  return tx;
}

function deleteTransaction(id) {
  ensureSheets_();
  var all = sheetToObjects_(SHEET_TX, TX_HEADERS);
  var tx = all.filter(function (t) { return t.id === id; })[0];
  if (tx && tx.allocations && tx.allocations.length) {
    // revert allocation amounts from goals
    var goals = listGoals();
    tx.allocations.forEach(function (alloc) {
      var goal = goals.filter(function (g) { return g.id === alloc.goalId; })[0];
      if (goal) {
        goal.savedAmount = Math.max(0, Number(goal.savedAmount || 0) - Number(alloc.amount || 0));
        updateObjectById_(SHEET_GOALS, GOAL_HEADERS, goal.id, goal);
      }
    });
  }
  if (tx && tx.type === 'expense' && tx.sourcePocketId) {
    var goals2 = listGoals();
    var pocket = goals2.filter(function (g) { return g.id === tx.sourcePocketId; })[0];
    if (pocket) {
      pocket.savedAmount = Number(pocket.savedAmount || 0) + Number(tx.amount || 0);
      updateObjectById_(SHEET_GOALS, GOAL_HEADERS, pocket.id, pocket);
    }
  }
  return deleteObjectById_(SHEET_TX, TX_HEADERS, id);
}

/* ============================== GOALS ============================== */

function listGoals() {
  ensureSheets_();
  return sheetToObjects_(SHEET_GOALS, GOAL_HEADERS).sort(function (a, b) { return a.createdAt - b.createdAt; });
}

function addGoal(goal) {
  ensureSheets_();
  goal.id = Utilities.getUuid();
  goal.createdAt = Date.now();
  goal.savedAmount = Number(goal.savedAmount || 0);
  goal.targetAmount = Number(goal.targetAmount || 0);
  goal.durationYears = Number(goal.durationYears || 1);
  goal.reminderEnabled = !!goal.reminderEnabled;
  goal.reminderDay = Number(goal.reminderDay || 1);
  var existingCount = listGoals().length;
  goal.color = GOAL_COLORS[existingCount % GOAL_COLORS.length];
  goal.allocations = goal.allocations || [];
  goal.allocations = goal.allocations.map(function (a) {
    a.id = a.id || Utilities.getUuid();
    a.createdAt = a.createdAt || Date.now();
    return a;
  });
  appendObject_(SHEET_GOALS, GOAL_HEADERS, goal);
  return goal;
}

function updateGoal(id, updates) {
  ensureSheets_();
  var goals = listGoals();
  var goal = goals.filter(function (g) { return g.id === id; })[0];
  if (!goal) return null;
  Object.keys(updates).forEach(function (k) { goal[k] = updates[k]; });
  updateObjectById_(SHEET_GOALS, GOAL_HEADERS, id, goal);
  return goal;
}

function deleteGoal(id) {
  ensureSheets_();
  return deleteObjectById_(SHEET_GOALS, GOAL_HEADERS, id);
}

function depositToGoal(id, amount) {
  ensureSheets_();
  var goals = listGoals();
  var goal = goals.filter(function (g) { return g.id === id; })[0];
  if (!goal) return null;
  goal.savedAmount = Number(goal.savedAmount || 0) + Number(amount || 0);
  updateObjectById_(SHEET_GOALS, GOAL_HEADERS, id, goal);
  return goal;
}

/* ============================== ALLOCATION ITEMS ============================== */

function addAllocationItem(goalId, item) {
  ensureSheets_();
  var goals = listGoals();
  var goal = goals.filter(function (g) { return g.id === goalId; })[0];
  if (!goal) return null;
  item.id = Utilities.getUuid();
  item.createdAt = Date.now();
  item.percentage = Number(item.percentage || 0);
  item.isAutomatic = !!item.isAutomatic;
  goal.allocations = goal.allocations || [];
  goal.allocations.push(item);
  updateObjectById_(SHEET_GOALS, GOAL_HEADERS, goalId, goal);
  return goal;
}

function updateAllocationItem(goalId, itemId, updates) {
  ensureSheets_();
  var goals = listGoals();
  var goal = goals.filter(function (g) { return g.id === goalId; })[0];
  if (!goal) return null;
  goal.allocations = (goal.allocations || []).map(function (a) {
    if (a.id === itemId) {
      Object.keys(updates).forEach(function (k) { a[k] = updates[k]; });
    }
    return a;
  });
  updateObjectById_(SHEET_GOALS, GOAL_HEADERS, goalId, goal);
  return goal;
}

function deleteAllocationItem(goalId, itemId) {
  ensureSheets_();
  var goals = listGoals();
  var goal = goals.filter(function (g) { return g.id === goalId; })[0];
  if (!goal) return null;
  goal.allocations = (goal.allocations || []).filter(function (a) { return a.id !== itemId; });
  updateObjectById_(SHEET_GOALS, GOAL_HEADERS, goalId, goal);
  return goal;
}

/* ============================== BOOTSTRAP / DASHBOARD ============================== */

function getInitialData() {
  ensureSheets_();
  return {
    transactions: listTransactions(),
    goals: listGoals(),
    settings: getSettings()
  };
}

function resetAllData() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  [SHEET_TX, SHEET_GOALS].forEach(function (name) {
    var sh = ss.getSheetByName(name);
    if (sh) {
      var last = sh.getLastRow();
      if (last > 1) sh.deleteRows(2, last - 1);
    }
  });
  return true;
}

/* ============================== DATE HELPERS ============================== */

function tz_() { return Session.getScriptTimeZone() || 'GMT+7'; }

function toISO_(d) { return Utilities.formatDate(d, tz_(), 'yyyy-MM-dd'); }

function formatDateID_(d) {
  return d.getDate() + ' ' + MONTHS_ID[d.getMonth()] + ' ' + d.getFullYear();
}

function startOfDay_(d) { var r = new Date(d); r.setHours(0, 0, 0, 0); return r; }
function endOfDay_(d) { var r = new Date(d); r.setHours(23, 59, 59, 999); return r; }

function startOfWeek_(d) {
  var r = new Date(d);
  var day = r.getDay();
  var diff = (day === 0 ? -6 : 1 - day);
  r.setDate(r.getDate() + diff);
  return startOfDay_(r);
}
function endOfWeek_(d) {
  var s = startOfWeek_(d);
  var r = new Date(s);
  r.setDate(r.getDate() + 6);
  return endOfDay_(r);
}

function getPeriodRange_(period, refDateISO) {
  var ref = refDateISO ? new Date(refDateISO + 'T00:00:00') : new Date();
  var start, end, label;
  switch (period) {
    case 'daily':
      start = startOfDay_(ref); end = endOfDay_(ref);
      label = formatDateID_(ref);
      break;
    case 'weekly':
      start = startOfWeek_(ref); end = endOfWeek_(ref);
      label = formatDateID_(start) + ' – ' + formatDateID_(end);
      break;
    case 'semester':
      var sem = ref.getMonth() < 6 ? 1 : 2;
      start = new Date(ref.getFullYear(), sem === 1 ? 0 : 6, 1);
      end = endOfDay_(new Date(ref.getFullYear(), sem === 1 ? 5 : 11, sem === 1 ? 30 : 31));
      label = 'Semester ' + sem + ' ' + ref.getFullYear();
      break;
    case 'yearly':
      start = new Date(ref.getFullYear(), 0, 1);
      end = endOfDay_(new Date(ref.getFullYear(), 11, 31));
      label = 'Tahun ' + ref.getFullYear();
      break;
    case 'monthly':
    default:
      start = new Date(ref.getFullYear(), ref.getMonth(), 1);
      end = endOfDay_(new Date(ref.getFullYear(), ref.getMonth() + 1, 0));
      label = MONTHS_ID[ref.getMonth()] + ' ' + ref.getFullYear();
      break;
  }
  return { start: start, end: end, label: label };
}

/* ============================== REPORTS ============================== */

function buildReportData_(period, refDateISO) {
  var range = getPeriodRange_(period, refDateISO);
  var all = listTransactions();
  var filtered = all.filter(function (t) {
    var d = new Date(t.date + 'T00:00:00');
    return d >= range.start && d <= range.end;
  }).sort(function (a, b) { return a.date.localeCompare(b.date); });

  var totalIncome = 0, totalExpense = 0;
  var byCategory = {};
  filtered.forEach(function (t) {
    if (t.type === 'income') totalIncome += t.amount; else totalExpense += t.amount;
    if (t.type === 'expense') {
      byCategory[t.category] = (byCategory[t.category] || 0) + t.amount;
    }
  });
  var categoryBreakdown = Object.keys(byCategory).map(function (k) {
    return { category: k, total: byCategory[k], pct: totalExpense ? Math.round(byCategory[k] / totalExpense * 100) : 0 };
  }).sort(function (a, b) { return b.total - a.total; });

  return {
    period: period,
    periodLabel: range.label,
    startISO: toISO_(range.start),
    endISO: toISO_(range.end),
    transactions: filtered,
    totalIncome: totalIncome,
    totalExpense: totalExpense,
    net: totalIncome - totalExpense,
    savingRate: totalIncome ? Math.round((totalIncome - totalExpense) / totalIncome * 100) : 0,
    categoryBreakdown: categoryBreakdown
  };
}

function getReport(period, refDateISO) {
  ensureSheets_();
  return buildReportData_(period, refDateISO);
}

function getAnalytics(refDateISO) {
  ensureSheets_();
  var ref = refDateISO ? new Date(refDateISO + 'T00:00:00') : new Date();
  var monthly = buildReportData_('monthly', toISO_(ref));

  var last6 = [];
  for (var i = 5; i >= 0; i--) {
    var d = new Date(ref.getFullYear(), ref.getMonth() - i, 1);
    var r = buildReportData_('monthly', toISO_(d));
    last6.push({ label: MONTHS_ID[d.getMonth()].slice(0, 3) + ' ' + d.getFullYear(), income: r.totalIncome, expense: r.totalExpense });
  }

  var goals = listGoals();
  var allocationSummary = [];
  var totalAllocPct = 0;
  goals.forEach(function (g) {
    (g.allocations || []).forEach(function (a) {
      allocationSummary.push({ goalId: g.id, goalName: g.name, type: a.type, percentage: a.percentage, isAutomatic: a.isAutomatic });
      totalAllocPct += Number(a.percentage || 0);
    });
  });

  return {
    monthly: monthly,
    last6Months: last6,
    allocationSummary: allocationSummary,
    totalAllocPct: totalAllocPct
  };
}

/* ============================== EXPORT: PDF / DOCX / XLSX ============================== */

function formatIDR_(n) {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

function generateReportDoc_(reportData, title) {
  var doc = DocumentApp.create(title);
  var body = doc.getBody();
  body.appendParagraph('FinTrack — Laporan Keuangan').setHeading(DocumentApp.ParagraphHeading.TITLE);
  body.appendParagraph('Periode: ' + reportData.periodLabel).setHeading(DocumentApp.ParagraphHeading.NORMAL);
  body.appendParagraph('Total Pemasukan: ' + formatIDR_(reportData.totalIncome));
  body.appendParagraph('Total Pengeluaran: ' + formatIDR_(reportData.totalExpense));
  body.appendParagraph('Saldo Bersih: ' + formatIDR_(reportData.net));
  body.appendParagraph('Saving Rate: ' + reportData.savingRate + '%');
  body.appendParagraph('');
  body.appendParagraph('Rincian Transaksi').setHeading(DocumentApp.ParagraphHeading.HEADING2);

  var table = body.appendTable();
  var header = table.appendTableRow();
  ['Tanggal', 'Tipe', 'Kategori', 'Catatan', 'Jumlah'].forEach(function (h) { header.appendTableCell(h); });
  if (reportData.transactions.length === 0) {
    var row = table.appendTableRow();
    row.appendTableCell('Tidak ada transaksi pada periode ini.');
  } else {
    reportData.transactions.forEach(function (tx) {
      var row = table.appendTableRow();
      row.appendTableCell(tx.date);
      row.appendTableCell(tx.type === 'income' ? 'Pemasukan' : 'Pengeluaran');
      row.appendTableCell(tx.category || '-');
      row.appendTableCell(tx.note || '-');
      row.appendTableCell((tx.type === 'income' ? '+' : '-') + formatIDR_(tx.amount));
    });
  }

  if (reportData.categoryBreakdown && reportData.categoryBreakdown.length) {
    body.appendParagraph('');
    body.appendParagraph('Distribusi Pengeluaran per Kategori').setHeading(DocumentApp.ParagraphHeading.HEADING2);
    var catTable = body.appendTable();
    var catHeader = catTable.appendTableRow();
    ['Kategori', 'Total', 'Persentase'].forEach(function (h) { catHeader.appendTableCell(h); });
    reportData.categoryBreakdown.forEach(function (c) {
      var row = catTable.appendTableRow();
      row.appendTableCell(c.category);
      row.appendTableCell(formatIDR_(c.total));
      row.appendTableCell(c.pct + '%');
    });
  }

  doc.saveAndClose();
  return DriveApp.getFileById(doc.getId());
}

function safeFileLabel_(reportData, period) {
  return ('FinTrack_' + period + '_' + reportData.periodLabel).replace(/[^a-zA-Z0-9]+/g, '_');
}

function exportReportPdf(period, refDateISO) {
  ensureSheets_();
  var reportData = buildReportData_(period, refDateISO);
  var file = generateReportDoc_(reportData, 'FinTrack Laporan ' + reportData.periodLabel);
  var pdfBlob = file.getAs('application/pdf');
  var base64 = Utilities.base64Encode(pdfBlob.getBytes());
  file.setTrashed(true);
  return { base64: base64, filename: safeFileLabel_(reportData, period) + '.pdf', mime: 'application/pdf' };
}

function exportReportDocx(period, refDateISO) {
  ensureSheets_();
  var reportData = buildReportData_(period, refDateISO);
  var file = generateReportDoc_(reportData, 'FinTrack Laporan ' + reportData.periodLabel);
  var url = 'https://docs.google.com/document/d/' + file.getId() + '/export?format=docx';
  var res = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true });
  var base64 = Utilities.base64Encode(res.getContent());
  file.setTrashed(true);
  return { base64: base64, filename: safeFileLabel_(reportData, period) + '.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' };
}

function exportReportExcel(period, refDateISO) {
  ensureSheets_();
  var reportData = buildReportData_(period, refDateISO);
  var ss = SpreadsheetApp.create('FinTrack Laporan ' + reportData.periodLabel);
  var sh = ss.getSheets()[0];
  sh.setName('Laporan');
  sh.appendRow(['FinTrack - Laporan Keuangan']);
  sh.appendRow(['Periode', reportData.periodLabel]);
  sh.appendRow(['Total Pemasukan', reportData.totalIncome]);
  sh.appendRow(['Total Pengeluaran', reportData.totalExpense]);
  sh.appendRow(['Saldo Bersih', reportData.net]);
  sh.appendRow(['Saving Rate (%)', reportData.savingRate]);
  sh.appendRow([]);
  sh.appendRow(['Tanggal', 'Tipe', 'Kategori', 'Catatan', 'Jumlah']);
  reportData.transactions.forEach(function (tx) {
    sh.appendRow([tx.date, tx.type === 'income' ? 'Pemasukan' : 'Pengeluaran', tx.category || '-', tx.note || '-', tx.amount]);
  });
  SpreadsheetApp.flush();
  var id = ss.getId();
  var url = 'https://docs.google.com/spreadsheets/d/' + id + '/export?format=xlsx';
  var res = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true });
  var base64 = Utilities.base64Encode(res.getContent());
  DriveApp.getFileById(id).setTrashed(true);
  return { base64: base64, filename: safeFileLabel_(reportData, period) + '.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };
}

function exportAllDataExcel() {
  ensureSheets_();
  var transactions = listTransactions();
  var goals = listGoals();
  var ss = SpreadsheetApp.create('FinTrack Semua Data');
  var sh1 = ss.getSheets()[0];
  sh1.setName('Transaksi');
  sh1.appendRow(['Tanggal', 'Tipe', 'Kategori', 'Catatan', 'Jumlah', 'Alokasi']);
  transactions.forEach(function (t) {
    var allocStr = (t.allocations || []).map(function (a) { return a.goalName + ': ' + formatIDR_(a.amount); }).join(', ');
    sh1.appendRow([t.date, t.type === 'income' ? 'Pemasukan' : 'Pengeluaran', t.category, t.note, t.amount, allocStr]);
  });
  var sh2 = ss.insertSheet('Target & Alokasi');
  sh2.appendRow(['Target', 'Terkumpul', 'Tujuan', 'Jangka (thn)', 'Jenis Alokasi', 'Persentase', 'Otomatis']);
  goals.forEach(function (g) {
    if (!g.allocations || !g.allocations.length) {
      sh2.appendRow([g.name, g.savedAmount, g.targetAmount, g.durationYears, '-', '-', '-']);
    } else {
      g.allocations.forEach(function (a) {
        sh2.appendRow([g.name, g.savedAmount, g.targetAmount, g.durationYears, a.type, a.percentage + '%', a.isAutomatic ? 'Ya' : 'Tidak']);
      });
    }
  });
  SpreadsheetApp.flush();
  var id = ss.getId();
  var url = 'https://docs.google.com/spreadsheets/d/' + id + '/export?format=xlsx';
  var res = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true });
  var base64 = Utilities.base64Encode(res.getContent());
  DriveApp.getFileById(id).setTrashed(true);
  return { base64: base64, filename: 'FinTrack_Semua_Data.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };
}
